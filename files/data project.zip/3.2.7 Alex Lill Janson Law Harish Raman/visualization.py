####
#NOTE: WHEN RUNNING THIS CODE, EXPAND GRAPHS TO FULLSCREEN. CODE IS OPTIMIZED FOR 16:9 ASPECT RATIO DISPLAYS.
#Alex Lill
#Harish Raman
#Janson Law
#Traffic stop data from: https://catalog.data.gov/dataset/officer-traffic-stops
#Charlotte, NC population proportions from: http://www.census.gov/quickfacts/table/PST045215/3712000
####
import matplotlib
matplotlib.use("TkAgg") #Used to switch the backend to Tkinter to display graphs for computers that do not have it set as the default.
import matplotlib.pyplot as plt
import os.path

directory = os.path.dirname(os.path.abspath(__file__)) #Variable 'directory' is saved as the path to the file
filename = os.path.join(directory, 'Officer_Traffic_Stops.csv') #Filename is variable 'directory' plus the file name 'Officer...'
datafile = open(filename) #Saves the data into a variable
data = datafile.readlines()

###
#Initializes lists and iterates through data to find the lengths of the traffic stops for folowwing groups: Majority (White), Minority (defined below), African American, Asian American/Pacific Islander, Hispanic/Latino, and other races.
###
stop = []
minorityStop = []
majorityStop = []
aaStop = []
asStop = []
hiStop = []
minority = ['Black/African American' ,'Asian / Pacific Islander', 'Hispanic/Latino', 'Native Hawaiian/Oth Pac Island', 'American Indian/Alaska Native', 'Not Specified'] #Defines minority category

for line in data[1:]: # Omit the single header line
    null,null,race,null,null,null,null,null,null,null,null,null,null,null,null,null,null = line.split(',') #line.split() requires an exact number of variables to unpack data into. We are only interested in the third item in the tuple, so the rest of the varuables are thrown under the arbitrary title "null" to represent their unimportance.
    stop.append(race) #Appends the race to a full list of every traffic stop for later comparison.
    if race in minority: #This if:else establishes a list containing the minority and majority race stops for later comparison.
        minorityStop.append(race)
    else:
        majorityStop.append(race)
    if race == minority[0]: #Next three if statements create lists for the minority groups of African Americans, Asians/Pacific Islanders, Hispanic/Latinos, and other races respectively.
        aaStop.append(race)
    if race == minority[1]:
        asStop.append(race)
    if race == minority[2]:
        hiStop.append(race)
stop = len(stop) #Stop is saved as the total number of traffic stops.

###
#Finds population proportions of race for Charlotte, NC, the same city where the above data was collected.
###
filename = os.path.join(directory, 'charlotteNC.csv') #Creates new direct filepath for charlotteNC.csv
datafile = open(filename)
data = datafile.readlines()
        
line = data[20] #Finds proportions for races
whiteProp=line.split(',') #Each line is split into a list item containing all information read until a comma is reached. At this point, the next list item begins.
whiteProp = whiteProp[4] #The 5th list item contains the proportion.

line = data[22]
aaProp=line.split(',')
aaProp = aaProp[4]

line = data[26] #Asian and Pacific Islander are grouped together to match the data from the traffic stops
asProp = line.split(',')
asProp = asProp[4]
line = data[28]
aiProp = line.split(',')
aiProp = aiProp[4]
asProp = float(aiProp) + int(asProp)

line = data[32]
hiProp = line.split(',')
hiProp = hiProp[4]

#graph one (ax[0])
majMin = (len(majorityStop)/float(stop),len(minorityStop)/float(stop)) #Finds propotion of traffic stops by race: Number of a given race stopped divided by all stops gives the proportion of stops for the given race.
labels=('Majority Groups','Minority Groups') #Names labels for pie chart

#graph two (ax[1])
x21Pos = (1,2,3,4) #Sets positions of the left bar in the pairs
x22Pos = (1.3,2.3,3.3,4.3) #Sets positions of the right bar in the pairs (bars are .3 wide, so placing the leftmost side at x=1.3 places the bars directly next to each other.)
popProp = (whiteProp,aaProp,asProp,hiProp) #Bars to use for the left bar of each pair, or the population proportion
stopProp = (100*len(majorityStop)/float(stop),100*len(aaStop)/float(stop),100*len(aaStop)/float(stop),100*len(hiStop)/float(stop)) #Bars to use for the right side of each pair, or proportion of traffic stops
#########

#Graph one    
fig, ax  = plt.subplots(1, 2) #Create a window with two subplote
ax[0].pie(majMin,autopct='%1.1f%%',colors=('#ea7777','#a2abef'),labels=labels) #Pie chart on subplot 0 using data from variable 'majMin', show area percentage on graph, use given colors, and the labels are taken from the variable 'labels'.
ax[0].set_title('Traffic Stops on Majority Groups and Minority Groups') #Sets title of graph

#Graph two
ax[1].bar(x21Pos, popProp, width=.3, color='#adfff9', tick_label=None) #Bar graph on subplot 1 using positions from x21pos, data from popProp, width of .3 units, the given color, with no tick labels.
ax[1].bar(x22Pos, stopProp, width=.3, color='#f9df81',tick_label=None) #Bar graph on subplot 1 using positions from x22pos, data from stopProp, width of .3 units, the given color, with no tick labels.
ax[1].tick_params(labelbottom='off')  #Remove bottom tick labels
ax[1].set_ylabel('Percentage') #Labels the y-axis 'Percentage'
ax[1].set_title('Population Proportion and Traffic Stop Proportion versus Race') #Changes title to the given string
ax[1].text(1.2,-2,'White') #Labels bars representing White people
ax[1].text(2.2,-2,'Afr. Amer.') #Labels bars representing African American people
ax[1].text(3.2,-2,'Asian') #Labels bars representing Asian people
ax[1].text(3.2,-2,'Hispanic/Latino') #labels bars representing Hispanic/Latino people

plt.show() #Displays graph